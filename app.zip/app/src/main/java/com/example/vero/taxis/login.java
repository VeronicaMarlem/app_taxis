package com.example.vero.taxis;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class login extends AppCompatActivity implements View.OnClickListener {

    Button facebook;
    Button twitter;
    Button insta;
    Button acceder;
    private TextView recuperar;
    private TextView registrar;
    private String direccion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        facebook = (Button)findViewById(R.id.btnfacebook);
        twitter = (Button)findViewById(R.id.btntwitter);
        insta = (Button)findViewById(R.id.btninsta);
        acceder = (Button)findViewById(R.id.btnacceder);
        recuperar = (TextView)findViewById(R.id.txtrecuperar);
        registrar = (TextView)findViewById(R.id.txtregistrar);

        acceder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent acceder = new Intent(login.this , menu.class);
                startActivity(acceder);
            }
        });

        registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registrar = new Intent(login.this , registro.class);
                startActivity(registrar);
            }
        });

        facebook.setOnClickListener(this);
        twitter.setOnClickListener(this);
        insta.setOnClickListener(this);
        recuperar.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.btnfacebook:
                direccion = "http://www.facebook.com";
                IrAweb(direccion);
                break;

            case R.id.btntwitter:
                direccion = "http://www.twitter.com";
                IrAweb(direccion);
                break;

            case R.id.btninsta:
                direccion = "http://www.instagram.com";
                IrAweb(direccion);
                break;

            case R.id.txtrecuperar:
                direccion = "http://www.gmail.com";
                IrAweb(direccion);
                break;

            default:
                break;
        }

    }

    public void IrAweb(String d){
        Uri uri = Uri.parse(d);
        Intent intentNav = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intentNav);
    }
}
