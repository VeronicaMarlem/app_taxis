package com.example.vero.taxis;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public abstract class registro extends AppCompatActivity {

    private Spinner spinnerdiscap;
    private Button reg_acceder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        spinnerdiscap = findViewById(R.id.spinnerdiscap);
        reg_acceder = (Button)findViewById(R.id.btnacceder);

        ArrayList<String> discapacidades = new ArrayList<>();

        discapacidades.add("Selecciona");
        discapacidades.add("Discapacidad 1");
        discapacidades.add("Discapacidad 2");
        discapacidades.add("Discapacidad 3");
        discapacidades.add("Discapacidad 4");
        discapacidades.add("Discapacidad 5");
        discapacidades.add("Ninguna");

        ArrayAdapter adp = new ArrayAdapter(registro.this, android.R.layout.simple_spinner_dropdown_item, discapacidades);

        spinnerdiscap.setAdapter(adp);

        spinnerdiscap.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String discapacidades = (String) spinnerdiscap.getAdapter().getItem(position);

                Toast.makeText(registro.this, "Seleccionaste: "+discapacidades, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        reg_acceder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent reg_acceder = new Intent(registro.this , menu.class);
                startActivity(reg_acceder);
            }
        });
    }
}
